import React, { useMemo, useRef, useState } from 'react';
import { AutoComplete, Spin } from 'antd';

type Option = { value: string; label?: React.ReactNode; x: string };

export default function SppCustomAutoComplete() {
  const [open, setOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [items, setItems] = useState<Option[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);

  const reqIdRef = useRef(0);

  const options = useMemo(() => items, [items]);

  const fetchPage = async (q: string, nextPage: number) => {
    if (loading) return;
    if (!hasMore && nextPage !== 1) return;

    setLoading(true);
    const reqId = ++reqIdRef.current;

    try {
      // TODO: 너희 API로 교체
      const res = await fakeApi(q, nextPage);

      if (reqId !== reqIdRef.current) return; // 레이스 방지

      setItems((prev) => (nextPage === 1 ? res.items : [...prev, ...res.items]));
      setHasMore(res.hasMore);
      setPage(nextPage);
    } finally {
      if (reqId === reqIdRef.current) setLoading(false);
    }
  };

  const resetAndSearch = (q: string) => {
    setHasMore(true);
    setPage(1);
    fetchPage(q, 1);
  };

  return (
    <AutoComplete
      open={open}
      onOpenChange={setOpen}
      options={options}
      value={inputValue}
      onChange={(v) => {
        const q = String(v ?? '');
        setInputValue(q);
        resetAndSearch(q); // 필요하면 debounce 걸어줘
      }}
      onPopupScroll={(e) => {
        const el = e.target as HTMLDivElement;
        const threshold = 40;
        const nearBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - threshold;

        if (nearBottom && !loading && hasMore) {
          fetchPage(inputValue, page + 1);
        }
      }}
      popupRender={(menu) => {
        console.log(menu);
        return (
          <>
            {menu}
            <div style={{ padding: 8, textAlign: 'center' }}>{loading ? <Spin size="small" /> : !hasMore ? '끝!' : null}</div>
          </>
        );
      }}
      placeholder="검색어 입력"
      style={{ width: 320 }}
    />
  );
}

// 데모용
async function fakeApi(q: string, page: number) {
  await new Promise((r) => setTimeout(r, 250));
  const pageSize = 20;
  const total = 93;

  const start = (page - 1) * pageSize;
  const end = Math.min(start + pageSize, total);

  const items = Array.from({ length: Math.max(0, end - start) }, (_, i) => {
    const idx = start + i + 1;
    return { value: `${q || 'item'}-${idx}`, x: '1' };
  });

  return { items, hasMore: end < total };
}
